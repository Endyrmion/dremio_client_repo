dremio\_client package
======================

Subpackages
-----------

.. toctree::

    dremio_client.auth
    dremio_client.conf
    dremio_client.flight
    dremio_client.model
    dremio_client.util

Submodules
----------

dremio\_client.cli module
-------------------------

.. automodule:: dremio_client.cli
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.dremio\_client module
------------------------------------

.. automodule:: dremio_client.dremio_client
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.dremio\_simple\_client module
--------------------------------------------

.. automodule:: dremio_client.dremio_simple_client
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.error module
---------------------------

.. automodule:: dremio_client.error
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: dremio_client
    :members:
    :undoc-members:
    :show-inheritance:
