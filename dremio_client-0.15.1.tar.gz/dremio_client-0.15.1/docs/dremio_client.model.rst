dremio\_client.model package
============================

Submodules
----------

dremio\_client.model.catalog module
-----------------------------------

.. automodule:: dremio_client.model.catalog
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.model.data module
--------------------------------

.. automodule:: dremio_client.model.data
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.model.endpoints module
-------------------------------------

.. automodule:: dremio_client.model.endpoints
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: dremio_client.model
    :members:
    :undoc-members:
    :show-inheritance:
