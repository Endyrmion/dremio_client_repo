dremio\_client.flight package
=============================

Submodules
----------

dremio\_client.flight.command\_pb2 module
-----------------------------------------

.. automodule:: dremio_client.flight.command_pb2
    :members:
    :undoc-members:
    :show-inheritance:

dremio\_client.flight.flight\_auth module
-----------------------------------------

.. automodule:: dremio_client.flight.flight_auth
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: dremio_client.flight
    :members:
    :undoc-members:
    :show-inheritance:
