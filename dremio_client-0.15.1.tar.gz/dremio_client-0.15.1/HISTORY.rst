=======
History
=======

0.1.0 (2019-07-04)
------------------

* First code, unreleased.

0.2.4 (2019-08-13)
------------------

* Alpha quality release with partial implementation of features. First PyPI release.

0.3.0 (2019-08-14)
------------------

* Beta quality release for GET based endpoints

0.5.0 (2019-10-30)
------------------

* Most endpoint supported
* flight support with tls & auth
* minor bugfixes

0.6.3 (2020-01-29)
------------------

* All endpoints supported
* lots of bugfixes
* utilities for building spaces/folders vds
* removed recordclass library in favor of attrs

0.8.4 (2020-01-29)
------------------

* history re-written

0.8.8 (2020-02-19)
------------------

* minor bug fixes

0.8.9 (2020-02-19)
------------------

* ensure use correct name for Spaces

0.8.11 (2020-03-09)
-------------------

* bug fixes when creating sources and folders

0.9.2 (2020-03-17)
------------------

* add promote endpoint
* update versions from pyup

0.10.1 (2020-03-19)
-------------------

* fix ssl verify flag in cli

0.11.1 (2020-04-09)
-------------------

* a number of bug fixes and improvements from the community

0.12.0 (2020-04-22)
-------------------

* add graph endpoint and cli flag
* add more detailed exception handling

0.12.1 (2020-05-04)
-------------------

* few bug fixes and API extensions

0.13.0 (2020-05-21)
-------------------

* add version flag
* upgrades and additions to some commands

0.13.1 (2020-05-21)
-------------------

* simplify delete cli command

0.13.2 (2020-05-22)
-------------------

* bugfixes

0.13.3 (2020-09-07)
-------------------

* fix wlm bug
* bump dependencies

0.13.6 (2020-09-16)
-------------------

* add new apis
* version bumps

0.14.0 (2021-04-01)
-------------------

* add new apis
* version bumps
* docs updates
* fix to query to produce correct pandas data frame
* fix to cli, dup args

0.15.1 (2021-08-26)
-------------------

* add new apis
* version bumps
