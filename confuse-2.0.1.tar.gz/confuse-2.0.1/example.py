#!/usr/bin/env python
import example

example.main()
