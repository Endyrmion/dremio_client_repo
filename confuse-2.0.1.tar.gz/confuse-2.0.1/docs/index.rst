.. include:: ../README.rst

.. toctree::
   :maxdepth: 3
   :hidden:

   usage
   examples
   changelog
   api
